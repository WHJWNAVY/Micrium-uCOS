/*
*********************************************************************************************************
*                                             uC/GUI V5.46
*                        Universal graphic software for embedded applications
*
*                       (c) Copyright 2018, Micrium Inc., Weston, FL
*                       (c) Copyright 2018, SEGGER Microcontroller GmbH & Co. KG
*
*              uC/GUI is protected by international copyright laws. Knowledge of the
*              source code may not be used to write a similar product. This file may
*              only be used in accordance with a license and should not be redistributed
*              in any way. We appreciate your understanding and fairness.
*
*********************************************************************************************************
File        : LCDConf.h
Purpose     : Display driver configuration file
*********************************************************************************************************
*/

#ifndef LCDCONF_H
#define LCDCONF_H

#endif /* LCDCONF_H */

/*************************** End of file ****************************/
