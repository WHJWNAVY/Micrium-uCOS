/*
*********************************************************************************************************
*                                            EXAMPLE CODE
*
*                          (c) Copyright 2009-2012; Micrium, Inc.; Weston, FL
*
*               All rights reserved.  Protected by international copyright laws.
*
*               Please feel free to use any application code labeled as 'EXAMPLE CODE' in
*               your application products.  Example code may be used as is, in whole or in
*               part, or may be used as a reference only.
*
*               Please help us continue to provide the Embedded community with the finest
*               software available.  Your honesty is greatly appreciated.
*
*               You can contact us at www.micrium.com.
*********************************************************************************************************
*/

/*
*********************************************************************************************************
*
*                                          APPLICATION CODE
*
*                                          Microsoft Windows
*
* Filename      : app.c
* Version       : V1.00
* Programmer(s) : JBL
*********************************************************************************************************
*/


/*
*********************************************************************************************************
*                                            INCLUDE FILES
*********************************************************************************************************
*/

#include  <app_cfg.h>

#include  <os.h>
#include  <os_cfg_app.h>

#include  <fs.h>
#include  <fs_app.h>
#include  <fs_file.h>
#include  <fs_dir.h>
#include  <fs_entry.h>


/*
*********************************************************************************************************
*                                            LOCAL DEFINES
*********************************************************************************************************
*/


/*
*********************************************************************************************************
*                                           LOCAL CONSTANTS
*********************************************************************************************************
*/


/*
*********************************************************************************************************
*                                          LOCAL DATA TYPES
*********************************************************************************************************
*/


/*
*********************************************************************************************************
*                                            LOCAL TABLES
*********************************************************************************************************
*/


/*
*********************************************************************************************************
*                                       LOCAL GLOBAL VARIABLES
*********************************************************************************************************
*/

static  OS_TCB   AppStartTaskTCB;
static  CPU_STK  AppStartTaskStk[APP_TASK_START_STK_SIZE];


/*
*********************************************************************************************************
*                                            LOCAL MACRO'S
*********************************************************************************************************
*/

#define  APP_TASK_STOP();                             { while (DEF_ON) { \
                                                            ;            \
                                                        }                \
                                                      }


#define  APP_TEST_FAULT(err_var, err_code)            { if ((err_var) != (err_code)) {   \
                                                            APP_TASK_STOP();             \
                                                        }                                \
                                                      }


/*
*********************************************************************************************************
*                                      LOCAL FUNCTION PROTOTYPES
*********************************************************************************************************
*/

static  void  App_TaskStart (void  *p_arg);

/*
*********************************************************************************************************
*                                     LOCAL CONFIGURATION ERRORS
*********************************************************************************************************
*/


/*
*********************************************************************************************************
*                                               main()
*
* Description : Entry point for C code.
*
* Arguments   : none.
*
* Returns     : none.
*
* Note(s)     : (1) It is assumed that your code will call main() once you have performed all necessary
*                   initialization.
*********************************************************************************************************
*/

int  main (void)
{
    OS_ERR  err_os;


    OSInit(&err_os);                                            /* Initialize uC/OS-III.                                */
    APP_TEST_FAULT(err_os, OS_ERR_NONE);

    OSTaskCreate((OS_TCB     *)&AppStartTaskTCB,                /* Create the startup task.                             */
                 (CPU_CHAR   *)"App Start Task",
                 (OS_TASK_PTR ) App_TaskStart,
                 (void       *) 0,
                 (OS_PRIO     ) APP_TASK_START_PRIO,
                 (CPU_STK    *)&AppStartTaskStk[0],
                 (CPU_STK_SIZE) APP_TASK_START_STK_SIZE / 10u,
                 (CPU_STK_SIZE) APP_TASK_START_STK_SIZE,
                 (OS_MSG_QTY  ) 0u,
                 (OS_TICK     ) 0u,
                 (void       *) 0,
                 (OS_OPT      )(OS_OPT_TASK_STK_CHK | OS_OPT_TASK_STK_CLR),
                 (OS_ERR     *)&err_os);
    APP_TEST_FAULT(err_os, OS_ERR_NONE);

    OSStart(&err_os);                                           /* Start multitasking (i.e. give control to uC/OS-III). */
    APP_TEST_FAULT(err_os, OS_ERR_NONE);
}


/*
*********************************************************************************************************
*                                           App_TaskStart()
*
* Description : Startup task example code.
*
* Arguments   : p_arg       Argument passed by 'OSTaskCreate()'.
*
* Returns     : none.
*
* Created by  : main().
*
*********************************************************************************************************
*/

static  void  App_TaskStart (void  *p_arg)
{
    CPU_BOOLEAN  cfg_success;
    FS_FILE     *p_file;
    FS_ERR       fs_err;
    CPU_CHAR     p_src_buf[] = "Hello World\r\n";
    CPU_CHAR     p_dest_buf[100];


   (void)&p_arg;                                                /* Prevent 'variable unused' compiler warning.          */

    CPU_Init();                                                 /* Initialize uC/CPU services.                          */

    Mem_Init();                                                 /* Initialize memory management module.                 */
    
    cfg_success = App_FS_Init();                                /* Initialize file system.                              */

    APP_TEST_FAULT(cfg_success, DEF_OK);

                                                                /* ------------------ USER APPLICATION ---------------- */

                                                                /* Create and open a file for writing.                  */
    p_file = FSFile_Open("ram:0:\\file.tst", FS_FILE_ACCESS_MODE_RDWR | FS_FILE_ACCESS_MODE_CREATE, &fs_err);
    APP_TEST_FAULT(fs_err, FS_ERR_NONE);

                                                                /* Write to the file.                                   */
    FSFile_Wr(p_file, p_src_buf, Str_Len(p_src_buf) + 1, &fs_err);
    APP_TEST_FAULT(fs_err, FS_ERR_NONE);

                                                                /* Reset the file position to 0.                        */
    FSFile_PosSet(p_file, 0, FS_FILE_ORIGIN_START, &fs_err);
    APP_TEST_FAULT(fs_err, FS_ERR_NONE);

                                                                /* Read back the data.                                  */
    FSFile_Rd(p_file, p_dest_buf, Str_Len(p_src_buf) + 1, &fs_err);
    APP_TEST_FAULT(fs_err, FS_ERR_NONE);

    APP_TRACE_INFO(("Read from ram:0:\\file.tst: %s", p_dest_buf));

                                                                /* Close the file.                                      */
    FSFile_Close(p_file, &fs_err);
    APP_TEST_FAULT(fs_err, FS_ERR_NONE);
}