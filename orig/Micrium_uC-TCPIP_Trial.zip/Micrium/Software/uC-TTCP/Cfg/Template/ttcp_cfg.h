/*
*********************************************************************************************************
*                                                uC/TTCP
*                                  TCP-IP Transfer Measurement Utility
*
*                          (c) Copyright 2003-2007; Micrium, Inc.; Weston, FL
*
*                   All rights reserved.  Protected by international copyright laws.
*                   Knowledge of the source code may not be used to write a similar
*                   product.  This file may only be used in accordance with a license
*                   and should not be redistributed in any way.
*********************************************************************************************************
*/

/*
*********************************************************************************************************
*
*                                  TCP-IP TRANSFER MEASUREMENT UTILITY
*
*                                      CONFIGURATION TEMPLATE FILE
*
* Filename      : ttcp_cfg.h
* Version       : V1.91
* Programmer(s) : CL
*                 JDH
*                 ITJ
*                 SR
*********************************************************************************************************
*/

/*
*********************************************************************************************************
*                                              TASKS NAMES
*********************************************************************************************************
*/

#define  TTCP_OS_CFG_TASK_NAME                  "TTCP"


/*
*********************************************************************************************************
*                                           TASKS PRIORITIES
*********************************************************************************************************
*/

#define  TTCP_OS_CFG_TASK_PRIO                            16


/*
*********************************************************************************************************
*                                              STACK SIZES
*                             Size of the task stacks (# of OS_STK entries)
*********************************************************************************************************
*/

#define  TTCP_OS_CFG_TASK_STK_SIZE                      1024


/*
*********************************************************************************************************
*                                                 TTCP
*********************************************************************************************************
*/

#define  TTCP_CFG_MAX_ACCEPT_TIMEOUT_MS                 5000    /* Maximum inactivity time (ms) on ACCEPT.              */
#define  TTCP_CFG_MAX_CONN_TIMEOUT_MS                   5000    /* Maximum inactivity time (ms) on CONNECT.             */
#define  TTCP_CFG_MAX_RX_TIMEOUT_MS                     5000    /* Maximum inactivity time (ms) on RX.                  */
#define  TTCP_CFG_MAX_TX_TIMEOUT_MS                     5000    /* Maximum inactivity time (ms) on TX.                  */

#define  TTCP_CFG_MAX_ACCEPT_RETRY                         3    /* Maximum number of retries on ACCEPT.                 */
#define  TTCP_CFG_MAX_CONN_RETRY                           3    /* Maximum number of retries on CONNECT.                */
#define  TTCP_CFG_MAX_RX_RETRY                             3    /* Maximum number of retries on RX.                     */
#define  TTCP_CFG_MAX_TX_RETRY                             3    /* Maximum number of retries on TX.                     */

#define  TTCP_CFG_BUF_LEN                               2048    /* Buffer length.                                       */

/*
*********************************************************************************************************
*                                                TRACING
*********************************************************************************************************
*/

#define  TRACE_LEVEL_OFF                                   0
#define  TRACE_LEVEL_INFO                                  1
#define  TRACE_LEVEL_DBG                                   2

#define  TTCP_TRACE_LEVEL                       TRACE_LEVEL_INFO
#define  TTCP_TRACE                             printf
