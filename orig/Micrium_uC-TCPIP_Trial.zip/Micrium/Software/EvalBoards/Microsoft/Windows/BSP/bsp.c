/*
*********************************************************************************************************
*                                     MICRIUM BOARD SUPPORT PACKAGE
*
*                          (c) Copyright 2005-2008; Micrium, Inc.; Weston, FL
*
*                   All rights reserved.  Protected by international copyright laws.
*                   Knowledge of the source code may not be used to write a similar
*                   product.  This file may only be used in accordance with a license
*                   and should not be redistributed in any way.
*********************************************************************************************************
*/

/*
*********************************************************************************************************
*
*                                         BOARD SUPPORT PACKAGE
*
*                                          INTEL X86 MAIN FILE
*
* Filename      : bsp.c
* Version       : V1.92
* Programmer(s) : SR
*                 FBJ
*********************************************************************************************************
*/

#include <includes.h>


/*
*********************************************************************************************************
*                                             getsSafe
*
* Description : This function reads the input from stdin and removes the '\n' at the end
*               of it.
*
* Argument(s) : buffer      pointer to a buffer that is to hold the characters read
*               count       the size in bytes of the buffer pointed to
*********************************************************************************************************
*/

void getsSafe(CPU_INT08U *buffer, CPU_INT32U count)
{
    CPU_INT08U *retVal;
    CPU_INT08U *np;

    if ((buffer == NULL) || (count < 1)) {
        buffer = NULL;
    }
    else if (count == 1) {
        *buffer = '\0';
    }
    else if ((retVal = fgets(buffer, count, stdin)) != NULL) {
        if (np = strchr(buffer, '\n')) {
            *np = '\0';
        }
    }
    
    return;
}


/*
*********************************************************************************************************
*                                          LED SERVICE FNCTS
*
* Note(s):  These empty functions are present for compatibility issues with other applications.
*********************************************************************************************************
*/

void  LED_Init   (void)
{
}

void  LED_On     (CPU_INT08U  led)
{
}

void  LED_Off    (CPU_INT08U  led)
{
}

void  LED_Toggle (CPU_INT08U  led)
{
}


/*
******************************************************************************************************************************
******************************************************************************************************************************
*                                  uC/Probe Plug-In for uC/OS-II Functions
******************************************************************************************************************************
******************************************************************************************************************************
*/

/*
*********************************************************************************************************
*                              INITIALIZE TIMER FOR uC/Probe Plug-In for uC/OS-II
*
* Description : This function is called to by uC/Probe Plug-In for uC/OS-II to initialize the
*               free running timer that is used to make time measurements.
*
* Arguments   : none
*
* Returns     : none
*
* Note(s)     : This function is EMPTY because the timer is initialized elsewhere.
*********************************************************************************************************
*/

#if (uC_PROBE_OS_PLUGIN > 0) && (OS_PROBE_HOOKS_EN == 1)
void  OSProbe_TmrInit (void)
{
}
#endif


/*
*********************************************************************************************************
*                              READ TIMER FOR uC/Probe Plug-In for uC/OS-II
*
* Description : This function is called to read the current counts of a 16 bit free running timer.
*
* Arguments   : none
*
* Returns     : The 16 or 32 bit count of the timer assuming the timer is an UP counter.
*********************************************************************************************************
*/

#if (uC_PROBE_OS_PLUGIN > 0) && (OS_PROBE_HOOKS_EN == 1)
CPU_INT32U  OSProbe_TmrRd (void)
{
    _int64  tmr_val;
    
    _asm rdtsc;
    _asm lea ebx,tmr_val;
    _asm mov [ebx],eax;
    _asm mov [ebx+4],edx;

    return ((CPU_INT32U)tmr_val);
}
#endif

