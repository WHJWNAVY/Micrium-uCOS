/*
*********************************************************************************************************
*                                     MICRIUM BOARD SUPPORT PACKAGE
*
*                          (c) Copyright 2005-2008; Micrium, Inc.; Weston, FL
*
*                   All rights reserved.  Protected by international copyright laws.
*                   Knowledge of the source code may not be used to write a similar
*                   product.  This file may only be used in accordance with a license
*                   and should not be redistributed in any way.
*********************************************************************************************************
*/

/*
*********************************************************************************************************
*
*                                         BOARD SUPPORT PACKAGE
*
*                                          INTEL X86 MAIN FILE
*
* Filename      : bsp.h
* Version       : V1.92
* Programmer(s) : SR
*********************************************************************************************************
*/


/*
*********************************************************************************************************
*                                               DEFINES
*
* Note(s) : (1) If C++ compiler used, define CPLUSPLUS.  This is used with variable length macros.
*
*********************************************************************************************************
*/

                                                                /* See Note #1.                                         */
#ifndef CPLUSPLUS
#define CPLUSPLUS
#endif


/*
*********************************************************************************************************
*                                               MACRO'S
*
* Note(s) :
*********************************************************************************************************
*/

                                                                /* Read from console                                    */
#define  Ser_RdStr(x,y)    gets(x)  


/*
*********************************************************************************************************
*                                          FUNCTION PROTOTYPES
*********************************************************************************************************
*/

void  getsSafe  (CPU_INT08U  *buffer,
                 CPU_INT32U   count);


/*
*********************************************************************************************************
*                                              LED SERVICES
*********************************************************************************************************
*/

void  LED_Init   (void);
void  LED_On     (CPU_INT08U  led);
void  LED_Off    (CPU_INT08U  led);
void  LED_Toggle (CPU_INT08U  led);

