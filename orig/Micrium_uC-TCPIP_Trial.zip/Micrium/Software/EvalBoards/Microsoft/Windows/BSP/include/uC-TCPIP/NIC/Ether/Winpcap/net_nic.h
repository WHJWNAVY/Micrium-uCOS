/*
*********************************************************************************************************
*                                              uC/TCP-IP
*                                      The Embedded TCP/IP Suite
*
*                          (c) Copyright 2003-2007; Micrium, Inc.; Weston, FL
*
*               All rights reserved.  Protected by international copyright laws.
*
*               uC/TCP-IP is provided in source form for FREE evaluation, for educational
*               use or peaceful research.  If you plan on using uC/TCP-IP in a commercial
*               product you need to contact Micrium to properly license its use in your
*               product.  We provide ALL the source code for your convenience and to help
*               you experience uC/TCP-IP.  The fact that the source code is provided does
*               NOT mean that you can use it without paying a licensing fee.
*
*               Network Interface Card (NIC) port files provided, as is, for FREE and do
*               NOT require any additional licensing or licensing fee.
*
*               Knowledge of the source code may NOT be used to develop a similar product.
*
*               Please help us continue to provide the Embedded community with the finest
*               software available.  Your honesty is greatly appreciated.
*********************************************************************************************************
*/

/*
*********************************************************************************************************
*
*                                        NETWORK INTERFACE CARD
*
*                                               winpcap
*
* Filename      : net_nic.h
* Version       : V1.90
* Programmer(s) : SR
*********************************************************************************************************
*/

#include  <pcap.h>
#include  <net_nic_os.h>


/*
*********************************************************************************************************
*                                               EXTERNS
*********************************************************************************************************
*/

#ifdef   NET_NIC_MODULE
#define  NET_NIC_EXT
#else
#define  NET_NIC_EXT  extern
#endif


/*
*********************************************************************************************************
*                                               DEFINES
*********************************************************************************************************
*/


/*
*********************************************************************************************************
*                               NIC DRIVER LAYER / ETHERNET ERROR CODES
*
* Note(s) : (1) ALL NIC-independent    error codes #define'd in      'net_err.h';
*               ALL winpcap-specific   error codes #define'd in this 'net_nic.h'.
*
*           (2) Network error code '10,000' series reserved for NIC drivers.
*********************************************************************************************************
*/

#define  WINPCAP_ERR_INIT                        10600
#define  WINPCAP_ERR_TX                          10610
#define  WINPCAP_ERR_RX                          10620


/*
*********************************************************************************************************
*                                             DATA TYPES
*********************************************************************************************************
*/


/*
*********************************************************************************************************
*                                          GLOBAL VARIABLES
*********************************************************************************************************
*/

NET_NIC_EXT  CPU_BOOLEAN  NetNIC_ConnStatus;                    /* NIC's connection status : DEF_ON/DEF_OFF.            */


#if (NET_CTR_CFG_STAT_EN == DEF_ENABLED)                        /* ------------------- NET DRV STATS ------------------ */
NET_NIC_EXT  NET_CTR      NetNIC_StatRxPktCtr;
NET_NIC_EXT  NET_CTR      NetNIC_StatTxPktCtr;
#endif

#if (NET_CTR_CFG_ERR_EN  == DEF_ENABLED)                        /* ------------------- NET DRV ERRS ------------------- */
NET_NIC_EXT  NET_CTR      NetNIC_ErrRxPktDiscardedCtr;
NET_NIC_EXT  NET_CTR      NetNIC_ErrTxPktDiscardedCtr;
#endif



/*$PAGE*/
/*
*********************************************************************************************************
*                                         FUNCTION PROTOTYPES
*********************************************************************************************************
*/

void         NetNIC_Init             (NET_ERR      *perr);

void         NetNIC_IntEn            (NET_ERR      *perr);



                                                                /* ------------------- STATUS FNCTS ------------------- */
void         NetNIC_ConnStatusChk    (void);

CPU_BOOLEAN  NetNIC_ConnStatusGet    (void);




void         NetNIC_ISR_Handler      (void);                    /* Decode & handle rx/tx ISRs.                          */



                                                                /* --------------------- RX FNCTS --------------------- */
CPU_INT16U   NetNIC_RxPktGetSize     (void);                    /* Get NIC rx pkt size.                                 */

void         NetNIC_RxPkt            (void         *ppkt,       /* Rx pkt from NIC.                                     */
                                      CPU_INT16U    size,
                                      NET_ERR      *perr);

void         NetNIC_RxPktDiscard     (CPU_INT16U    size,       /* Discard rx pkt in NIC.                               */
                                      NET_ERR      *perr);



                                                                /* --------------------- TX FNCTS --------------------- */
void         NetNIC_TxPkt            (void         *ppkt,
                                      CPU_INT16U    size,
                                      NET_ERR      *perr);



/*
*********************************************************************************************************
*                                         FUNCTION PROTOTYPES
*                                     DEFINED IN NIC'S  net_nic.c
*********************************************************************************************************
*/


/*$PAGE*/
/*
*********************************************************************************************************
*                                         FUNCTION PROTOTYPES
*                                      DEFINED IN OS'S  net_os.c
*********************************************************************************************************
*/

void         NetOS_NIC_Init          (NET_ERR      *perr);      /* Create Drv objs & start Drv tasks.                   */


void         NetOS_NIC_TxRdyWait     (NET_ERR      *perr);      /* Wait on drv tx rdy signal from NIC.                  */

void         NetOS_NIC_TxRdySignal   (void);                    /* Post    drv tx rdy signal from NIC.                  */


/*$PAGE*/
/*
*********************************************************************************************************
*                                         FUNCTION PROTOTYPES
*                                    DEFINED IN PRODUCT'S  net_bsp.c
*********************************************************************************************************
*/


/*
*********************************************************************************************************
*                                         FUNCTION PROTOTYPES
*                                  DEFINED IN PRODUCT's  net_bsp_a.s
*********************************************************************************************************
*/



/*
*********************************************************************************************************
*                                         FUNCTION PROTOTYPES
*                                    DEFINED IN PRODUCT'S  net_bsp.c
*
* Note(s) : (1) See this 'net_nic.c  wpcapInit()      Note #5'.
*
*           (2) See this 'net_nic.c  NetNIC_ISR_Handler()  Note #3'.
*********************************************************************************************************
*/

#if (NET_NIC_CFG_INT_CTRL_EN == DEF_ENABLED)
void         NetNIC_IntInit          (pcap_t *);                 /* Init int ctrl'r        [see Note #1].                */

void         NetNIC_IntClr           (void);                    /* Clr  int ctrl'r src(s) [see Note #2].                */
#endif


/*
*********************************************************************************************************
*                                        CONFIGURATION ERRORS
*********************************************************************************************************
*/

#ifndef  NET_NIC_CFG_INT_CTRL_EN
#error  "NET_NIC_CFG_INT_CTRL_EN           not #define'd in 'net_cfg.h'"
#error  "                            [MUST be  DEF_ENABLED]            "
#elif   (NET_NIC_CFG_INT_CTRL_EN != DEF_ENABLED)
#error  "NET_NIC_CFG_INT_CTRL_EN     illegally #define'd in 'net_cfg.h'"
#error  "                            [MUST be  DEF_ENABLED]            "
#endif



#ifndef  NET_NIC_CFG_RD_WR_SEL
#error  "NET_NIC_CFG_RD_WR_SEL             not #define'd in 'net_cfg.h'"
#error  "                            [MUST be  NET_NIC_RD_WR_SEL_FNCT ]"
#error  "                            [     ||  NET_NIC_RD_WR_SEL_MACRO]"
#elif  ((NET_NIC_CFG_RD_WR_SEL != NET_NIC_RD_WR_SEL_FNCT ) && \
        (NET_NIC_CFG_RD_WR_SEL != NET_NIC_RD_WR_SEL_MACRO))
#error  "NET_NIC_CFG_RD_WR_SEL       illegally #define'd in 'net_cfg.h'"
#error  "                            [MUST be  NET_NIC_RD_WR_SEL_FNCT ]"
#error  "                            [     ||  NET_NIC_RD_WR_SEL_MACRO]"
#endif
