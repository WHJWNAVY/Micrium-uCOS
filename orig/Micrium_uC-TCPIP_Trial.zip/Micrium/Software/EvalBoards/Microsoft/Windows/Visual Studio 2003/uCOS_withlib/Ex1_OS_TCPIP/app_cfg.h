/*
*********************************************************************************************************
*                                        uC/OS-II & uC/TCPIP
*                                             WIN32 SDK
*
*                          (c) Copyright 2006-2008; Micrium, Inc.; Weston, FL
*
*                   All rights reserved.  Protected by international copyright laws.
*                   Knowledge of the source code may not be used to write a similar
*                   product.  This file may only be used in accordance with a license
*                   and should not be redistributed in any way.
*********************************************************************************************************
*/

/*
*********************************************************************************************************
*                                          CONFIGURATION FILE
*
* Filename      : app_cfg.h
* Version       : V1.92
* Programmer(s) : SR
*                 JDH
*********************************************************************************************************
*/


/*
*********************************************************************************************************
*                                       MODULE ENABLE / DISABLE
*********************************************************************************************************
*/

#define  APP_TCPIP_EN                           DEF_ENABLED

#define  APP_TTCP_EN                            DEF_ENABLED


/*
*********************************************************************************************************
*                                              TASKS NAMES
*********************************************************************************************************
*/

#define  TTCP_OS_CFG_TASK_NAME                 "TTCP"


/*
*********************************************************************************************************
*                                           TASKS PRIORITIES
*
* Note(s) : (1) Changing those priorities won't have any impact since the OS and the TCP stack are
*               provided as static libraries.
*********************************************************************************************************
*/

#define  APP_START_TASK_PRIO                                       13
#define  TTCP_OS_CFG_TASK_PRIO                                     16

                                                                /* See Note #1                        */
#define  NET_OS_CFG_IF_RX_TASK_PRIO                                10
#define  NET_OS_CFG_TMR_TASK_PRIO                                  11
#define  NET_OS_CFG_WINPCAP_RX_POOLING_TASK_PRIO                   12

#define  OS_TASK_TMR_PRIO                         (OS_LOWEST_PRIO - 2)


/*
*********************************************************************************************************
*                                              STACK SIZES
*                             Size of the task stacks (# of OS_STK entries)
*
* Note(s) : (1) Changing those priorities won't have any impact since the OS and the TCP stack are
*               provided as static libraries.
*********************************************************************************************************
*/

#define  APP_START_TASK_STK_SIZE                         512
#define  TTCP_OS_CFG_TASK_STK_SIZE                      1024

                                                                /* See Note #1                        */
#define  NET_OS_CFG_TMR_TASK_STK_SIZE                   1024
#define  NET_OS_CFG_IF_RX_TASK_STK_SIZE                 1024
#define  NET_OS_CFG_WINPCAP_RX_POOLING_TASK_STK_SIZE    1024


/*
*********************************************************************************************************
*                                                 TTCP
*********************************************************************************************************
*/

#define  TTCP_CFG_MAX_ACCEPT_TIMEOUT_MS                 5000    /* Maximum inactivity time (ms) on ACCEPT.              */
#define  TTCP_CFG_MAX_CONN_TIMEOUT_MS                   5000    /* Maximum inactivity time (ms) on CONNECT.             */
#define  TTCP_CFG_MAX_RX_TIMEOUT_MS                     5000    /* Maximum inactivity time (ms) on RX.                  */
#define  TTCP_CFG_MAX_TX_TIMEOUT_MS                     5000    /* Maximum inactivity time (ms) on TX.                  */

#define  TTCP_CFG_MAX_ACCEPT_RETRY                         3    /* Maximum number of retries on ACCEPT.                 */
#define  TTCP_CFG_MAX_CONN_RETRY                           3    /* Maximum number of retries on CONNECT.                */
#define  TTCP_CFG_MAX_RX_RETRY                             3    /* Maximum number of retries on RX.                     */
#define  TTCP_CFG_MAX_TX_RETRY                             3    /* Maximum number of retries on TX.                     */

#define  TTCP_CFG_BUF_LEN                               2048    /* Buffer length.                                       */


/*
*********************************************************************************************************
*                                                  LIB
*********************************************************************************************************
*/

#define  LIB_STR_CFG_FP_EN                       DEF_ENABLED


/*
*********************************************************************************************************
*                                                TRACING
*********************************************************************************************************
*/

#define  TRACE_LEVEL_OFF                                   0
#define  TRACE_LEVEL_INFO                                  1
#define  TRACE_LEVEL_DBG                                   2

#define  APP_TRACE_LEVEL                        TRACE_LEVEL_DBG
#define  APP_TRACE                              printf

#define  TTCP_TRACE_LEVEL                       TRACE_LEVEL_INFO
#define  TTCP_TRACE                             printf


#define  APP_TRACE_INFO(x)                    ((APP_TRACE_LEVEL >= TRACE_LEVEL_INFO) ? (void)(APP_TRACE x) : (void)0)
#define  APP_TRACE_DBG(x)                     ((APP_TRACE_LEVEL >= TRACE_LEVEL_DBG ) ? (void)(APP_TRACE x) : (void)0)
