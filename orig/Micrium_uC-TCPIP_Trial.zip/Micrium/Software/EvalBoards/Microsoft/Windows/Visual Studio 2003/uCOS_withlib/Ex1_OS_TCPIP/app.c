/*
*********************************************************************************************************
*                                        uC/OS-II & uC/TCPIP
*                                             WIN32 SDK
*
*                          (c) Copyright 2006-2008; Micrium, Inc.; Weston, FL
*
*               All rights reserved.  Protected by international copyright laws.
*
*               Knowledge of the source code may NOT be used to develop a similar product.
*
*               Please help us continue to provide the Embedded community with the finest
*               software available.  Your honesty is greatly appreciated.
*********************************************************************************************************
*/

/*
*********************************************************************************************************
*                                            EXAMPLE CODE
*
* Filename      : app.c
* Version       : V1.98
* Programmer(s) : SR
*********************************************************************************************************
*/

/*
*********************************************************************************************************
*                                             INCLUDE FILES
*********************************************************************************************************
*/

#include  <includes.h>

#if APP_TCPIP_EN
#include  <net.h>
#endif

#if APP_TTCP_EN
#include  <ttcp.h>
#endif


/*
*********************************************************************************************************
*                                            LOCAL DEFINES
*********************************************************************************************************
*/


/*
*********************************************************************************************************
*                                           LOCAL VARIABLES
*********************************************************************************************************
*/

static  OS_STK       AppStartTaskStk[APP_START_TASK_STK_SIZE];

static  NET_IP_ADDR  AppIP_Addr;
static  NET_IP_ADDR  AppIP_Mask;
static  NET_IP_ADDR  AppIP_DfltGateway;
static  NET_IP_ADDR  AppIP_DNS_Srvr;


/*
*********************************************************************************************************
*                                            LOCAL TABLES
*********************************************************************************************************
*/


/*
*********************************************************************************************************
*                                      LOCAL FUNCTION PROTOTYPES
*********************************************************************************************************
*/

static  void       AppTaskStart        (void  *p_arg);
static  void       AppInit_TCPIP       (void);
void               Ex1_Test            (void);



/*
*********************************************************************************************************
*                                             C ENTRY POINT
*********************************************************************************************************
*/

int  main (void)
{
#if (OS_TASK_NAME_SIZE >= 16)
    CPU_INT08U  err;
#endif

#if 0
    BSP_Init();                                                 /* Initialize BSP.                                      */
#endif
    
    APP_TRACE_INFO(("Initialize OS...\n"));
    OSInit();                                                   /* Initialize OS.                                       */

                                                                /* Create start task.                                   */
    OSTaskCreateExt( AppTaskStart,
                    (void *)0,
                    (OS_STK *)&AppStartTaskStk[APP_START_TASK_STK_SIZE - 1],
                     APP_START_TASK_PRIO,
                     APP_START_TASK_PRIO,
                    (OS_STK *)&AppStartTaskStk[0],
                     APP_START_TASK_STK_SIZE,
                    (void *)0,
                     OS_TASK_OPT_STK_CHK | OS_TASK_OPT_STK_CLR);

                                                                /* Give a name to tasks.                                */
#if (OS_TASK_NAME_SIZE >= 16)
    OSTaskNameSet(APP_START_TASK_PRIO, "Start task", &err);
#endif

    AppInit_TCPIP();                                            /* Initialize TCP/IP stack.                             */

    APP_TRACE_INFO(("Start OS...\n"));
    OSStart();                                                  /* Start OS.                                            */
}


/*
*********************************************************************************************************
*                                           App_TaskStart()
*
* Description : Startup task example code
*
* Arguments   : p_arg       Argument passed by 'OSTaskCreate'.
*
* Returns     : none.
*
* Note(s)     : (2) The first line of code is used to prevent a compiler warning because 'p_arg' is not
*                   used.  The compiler should not generate any code for this statement.
*********************************************************************************************************
*/

static  void  AppTaskStart (void  *p_arg)
{
    (void)p_arg;                                                /* Prevent compiler warning.                            */

#if 0
    APP_TRACE_INFO(("Initialize interrupt controller...\n"));
    BSP_InitIntCtrl();                                          /* Initialize interrupt controller.                     */

    APP_TRACE_INFO(("Initialize OS timer...\n"));
    Tmr_Init();                                                 /* Initialize OS timer.                                 */
#endif

#if (OS_TASK_STAT_EN > 0)
    APP_TRACE_INFO(("Initialize OS statistic task...\n"));
    OSStatInit();                                               /* Initialize OS statistic task.                        */
#endif

    APP_TRACE_INFO(("\n****************************************************************************"));
    APP_TRACE_INFO(("\n*                                                                          *"));
    APP_TRACE_INFO(("\n*                   Micrium uC/OS-II and uC/TCPIP for win32                *"));
    APP_TRACE_INFO(("\n*                               Windows PC SDK                             *"));
    APP_TRACE_INFO(("\n*                                                                          *"));
    APP_TRACE_INFO(("\n****************************************************************************"));
    APP_TRACE_INFO(("\n"));

    TTCP_OS_Init(NULL);

    while (DEF_YES) {                                           /* Task body, always written as an infinite loop.       */
        OSTimeDlyHMSM(0, 0, 1,0);
    }
}


/*
*********************************************************************************************************
*                                            App_InitTCPIP()
*
* Description : Initialize TCP-IP stack.
*
* Arguments   : none.
*
* Returns     : none.
*
* Caller(s)   : App_TaskStart().
*
* Note(s)     : none.
*********************************************************************************************************
*/

static  void  AppInit_TCPIP (void)
{
    NET_ERR      err;

    NET_IP_ADDR  ip;
    NET_IP_ADDR  msk;
    NET_IP_ADDR  gateway;


    APP_TRACE_INFO(("Initialize TCP/IP stack...\n\n"));
                                                                /* Getting MAC address from env. variable                */
    NetASCII_Str_to_MAC(getenv("WINPCAP_MAC_ADDR"), NetIF_MAC_Addr, &err); 

    err = Net_Init();
    if (err != NET_ERR_NONE) {
        APP_TRACE_INFO(("Net_Init() failed: error #%d, line #%d.\n", err, __LINE__));
        while (DEF_YES) {
            ;
        }
    }

                                                                /* Configuring IP address, mask and default gateway     */
    ip      = NetASCII_Str_to_IP(getenv("WINPCAP_IP_ADDR"), &err);
    msk     = NetASCII_Str_to_IP(getenv("WINPCAP_MASK"), &err);
    gateway = NetASCII_Str_to_IP(getenv("WINPCAP_DEFAULT_GATEWAY"), &err);
    
    NetIP_CfgAddrThisHost(ip, msk);
    NetIP_CfgAddrDfltGateway(gateway);
    
    APP_TRACE_INFO(("MAC address = %s\n",   getenv("WINPCAP_MAC_ADDR")));
    APP_TRACE_INFO(("IP address  = %s\n",   getenv("WINPCAP_IP_ADDR")));
    APP_TRACE_INFO(("Subnet mask = %s\n",   getenv("WINPCAP_MASK")));
    APP_TRACE_INFO(("Gateway     = %s\n\n", getenv("WINPCAP_DEFAULT_GATEWAY")));

}


/*
*********************************************************************************************************
*                                      TEST APPLICATION
*********************************************************************************************************
*/

void  Ex1_Test (void)
{
    APP_TRACE_INFO(("Ex1_Test() function called\n"));
}


/*
*********************************************************************************************************
*********************************************************************************************************
**                                         uC/OS-II APP HOOKS
*********************************************************************************************************
*********************************************************************************************************
*/

#if (OS_APP_HOOKS_EN > 0)
/*
*********************************************************************************************************
*                                      TASK CREATION HOOK (APPLICATION)
*
* Description : This function is called when a task is created.
*
* Argument(s) : ptcb   is a pointer to the task control block of the task being created.
*
* Note(s)     : (1) Interrupts are disabled during this call.
*********************************************************************************************************
*/

void  App_TaskCreateHook (OS_TCB *ptcb)
{
#if ((uC_PROBE_OS_PLUGIN == DEF_ENABLED) && \
     (OS_PROBE_HOOKS_EN  == DEF_ENABLED))
    OSProbe_TaskCreateHook(ptcb);
#endif
}

/*
*********************************************************************************************************
*                                    TASK DELETION HOOK (APPLICATION)
*
* Description : This function is called when a task is deleted.
*
* Argument(s) : ptcb   is a pointer to the task control block of the task being deleted.
*
* Note(s)     : (1) Interrupts are disabled during this call.
*********************************************************************************************************
*/

void  App_TaskDelHook (OS_TCB *ptcb)
{
    (void)ptcb;
}


/*
*********************************************************************************************************
*                                      IDLE TASK HOOK (APPLICATION)
*
* Description : This function is called by OSTaskIdleHook(), which is called by the idle task.  This hook
*               has been added to allow you to do such things as STOP the CPU to conserve power.
*
* Argument(s) : none.
*
* Note(s)     : (1) Interrupts are enabled during this call.
*********************************************************************************************************
*/

void  App_TaskIdleHook (void)
{
}


/*
*********************************************************************************************************
*                                        STATISTIC TASK HOOK (APPLICATION)
*
* Description : This function is called by OSTaskStatHook(), which is called every second by uC/OS-II's
*               statistics task.  This allows your application to add functionality to the statistics task.
*
* Argument(s) : none.
*********************************************************************************************************
*/

void  App_TaskStatHook (void)
{
}


/*
*********************************************************************************************************
*                                        TASK SWITCH HOOK (APPLICATION)
*
* Description : This function is called when a task switch is performed.  This allows you to perform other
*               operations during a context switch.
*
* Argument(s) : none.
*
* Note(s)     : (1) Interrupts are disabled during this call.
*
*               (2) It is assumed that the global pointer 'OSTCBHighRdy' points to the TCB of the task that
*                   will be 'switched in' (i.e. the highest priority task) and, 'OSTCBCur' points to the
*                  task being switched out (i.e. the preempted task).
*********************************************************************************************************
*/

#if (OS_TASK_SW_HOOK_EN > 0)
void  App_TaskSwHook (void)
{
#if ((uC_PROBE_OS_PLUGIN == DEF_ENABLED) && \
     (OS_PROBE_HOOKS_EN  == DEF_ENABLED))
    OSProbe_TaskSwHook();
#endif
}
#endif


/*
*********************************************************************************************************
*                                     OS_TCBInit() HOOK (APPLICATION)
*
* Description : This function is called by OSTCBInitHook(), which is called by OS_TCBInit() after setting
*               up most of the TCB.
*
* Argument(s) : ptcb    is a pointer to the TCB of the task being created.
*
* Note(s)     : (1) Interrupts may or may not be ENABLED during this call.
*********************************************************************************************************
*/

void  App_TCBInitHook (OS_TCB *ptcb)
{
    (void)ptcb;
}


/*
*********************************************************************************************************
*                                        TICK HOOK (APPLICATION)
*
* Description : This function is called every tick.
*
* Argument(s) : none.
*
* Note(s)     : (1) Interrupts may or may not be ENABLED during this call.
*********************************************************************************************************
*/

#if (OS_TIME_TICK_HOOK_EN > 0)
void  App_TimeTickHook (void)
{
#if ((uC_PROBE_OS_PLUGIN == DEF_ENABLED) && \
     (OS_PROBE_HOOKS_EN  == DEF_ENABLED))
    OSProbe_TickHook();
#endif
}
#endif


#endif

