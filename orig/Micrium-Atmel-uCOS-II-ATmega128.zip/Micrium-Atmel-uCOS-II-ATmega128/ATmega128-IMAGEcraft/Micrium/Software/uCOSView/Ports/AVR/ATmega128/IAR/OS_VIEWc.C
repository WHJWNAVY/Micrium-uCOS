/*
*********************************************************************************************************
*                                               uC/OS-View
*
*                               (c) Copyright 2005, Micrium, Inc., Weston, FL
*                                           All Rights Reserved
*
*                                               Atmel AVR
*                                               ATmega128
*********************************************************************************************************
*/

#include <includes.h>

#if OS_VIEW_MODULE > 0

/*
*********************************************************************************************************
*                                              CONSTANTS
*********************************************************************************************************
*/

#define  BIT0    0x01
#define  BIT1    0x02
#define  BIT2    0x04
#define  BIT3    0x08
#define  BIT4    0x10
#define  BIT5    0x20
#define  BIT6    0x40
#define  BIT7    0x80

/*
*********************************************************************************************************
*                                      LOCAL FUNCTION PROTOTYPES
*********************************************************************************************************
*/

static  void  OSView_UARTInit(INT32U baud_rate);

/*$PAGE*/
/*
*********************************************************************************************************
*                                           EXIT uC/OS-View
*
* Description:
*
* Note(s)    :
*********************************************************************************************************
*/

void  OSView_Exit (void)
{
}

/*
*********************************************************************************************************
*                                           Obtain CPU name
*********************************************************************************************************
*/

void  OSView_GetCPUName (INT8U *s)
{
    OS_StrCopy(s, "AVR - ATmega128");
}

/*
*********************************************************************************************************
*                                  Obtain Interrupt Stack information
*********************************************************************************************************
*/

INT32U  OSView_GetIntStkBase (void)					
{
    return (0);										  /* We are not using an ISR stack                 */
}


INT32U  OSView_GetIntStkSize (void)
{
    return (0);										  /* We are not using an ISR stack                 */
}

/*$PAGE*/
/*
*********************************************************************************************************
*                                  INITIALISE uC/OS-View COM PORT + TIMER
*
* Description: Initialize the hardware required for the OS to run. This will work on any target hardware,
*              but may have to be tailored a little (regarding the clock frequency). Of course the same
*              holds true if for some reason you choose to use an other timer.
*********************************************************************************************************
*/

void  OSView_InitTarget (INT32U baud_rate)
{
    OSView_UARTInit(baud_rate);
    OSView_TmrInit();
}

/*
*********************************************************************************************************
*                                  INITIALISE uC/OS-View COM PORT
*********************************************************************************************************
*/

static  void  OSView_UARTInit (INT32U baud_rate)
{
    INT16U  divisor;
    INT16U  temp;


                                                     /* -------- INITIALIZE THE SERIAL PORT ---------- */
                                                     /* Compute baud rate divisor and round off        */
    temp    = (CPU_CLK_FREQ * 2) / (16 * baud_rate);
    divisor = (temp + 1) / 2 - 1;

#if OS_VIEW_COMM_SEL == OS_VIEW_COMM_0
    UBRR0H  = divisor >> 8;
    UBRR0L  = divisor & 0xFF;

    UCSR0A &= ~BIT1;                                 /* DO NOT double the USART transmission speed     */

    UCSR0B  =  BIT7 | BIT4 | BIT3;                   /* Enable USART Rx Complete Interrupt             */
                                                     /* Enable the receiver                            */
                                                     /* Enable the transmitter                         */

    UCSR0C  =  BIT2 | BIT1;                          /* 8 Bits, 1 stop, no parity                      */
#endif

#if OS_VIEW_COMM_SEL == OS_VIEW_COMM_1
    UBRR1H  = divisor >> 8;
    UBRR1L  = divisor & 0xFF;

    UCSR1A &= ~BIT1;                                 /* DO NOT double the USART transmission speed     */

    UCSR1B  =  BIT7 | BIT4 | BIT3;                   /* Enable USART Rx Complete Interrupt             */
                                                     /* Enable the receiver                            */
                                                     /* Enable the transmitter                         */

    UCSR1C  =  BIT2 | BIT1;                          /* 8 Bits, 1 stop, no parity                      */
#endif
}


/*
*********************************************************************************************************
*                                   INITIALISE uC/OS-View TIMER
*
* Note(s): 1) The timer needs to be setup as a FREE RUNNING counter which counts from 0x0000 to 0xFFFF
*             and then, rolls over to 0x0000.
*
*          2) The timer doesn't need to generate interrupts.
*********************************************************************************************************
*/

void  OSView_TmrInit (void)
{
#if OS_VIEW_TMR_SEL == OS_VIEW_TMR_1                 /* See if we use Timer #1                         */
    TCCR1B              =   0x00;                    /* Stop timer                                     */
    TCNT1               = 0xFFFF;                    /* Setup TCNT                                     */
    TCCR1A              =   0x00;                    /* Normal Mode, count up 0x0000 to 0xFFFF         */
    TCCR1B              =   0x04;                    /* Start timer, prescale by 256                   */
#endif

#if OS_VIEW_TMR_SEL == OS_VIEW_TMR_3                 /* See if we use Timer #3                         */
    TCCR3B              =   0x00;                    /* Stop timer                                     */
    TCNT3               = 0xFFFF;                    /* Setup TCNT                                     */
    TCCR3A              =   0x00;                    /* Normal Mode, count up 0x0000 to 0xFFFF         */
    TCCR3B              =   0x04;                    /* Start timer, prescale by 256                   */
#endif
}

/*$PAGE*/
/*
*********************************************************************************************************
*                                     Read uC/OS-View TIMER
*
* Note(s): 1) This function simply reads the current value of a 16-bit free-running UP timer.
*
*          2) The timer doesn't generate interrupts.
*********************************************************************************************************
*/

INT32U  OSView_TmrRd (void)
{
    INT16U  cnts;


#if OS_VIEW_TMR_SEL == OS_VIEW_TMR_1
    cnts                = (INT16U)TCNT1;                             /* Read current counts of Timer #1                  */
#endif

#if OS_VIEW_TMR_SEL == OS_VIEW_TMR_3
    cnts                = (INT16U)TCNT3;                             /* Read current counts of Timer #3                  */
#endif

    return ((INT32U)cnts);
}

/*$PAGE*/
/*
*********************************************************************************************************
*                                       Disable Rx Interrupts
*********************************************************************************************************
*/

void  OSView_RxIntDis (void)
{
#if OS_VIEW_COMM_SEL == OS_VIEW_COMM_0
    UCSR0B &= ~BIT7;
#endif

#if OS_VIEW_COMM_SEL == OS_VIEW_COMM_1
    UCSR1B &= ~BIT7;
#endif
}

/*
*********************************************************************************************************
*                                       Enable Rx Interrupts
*********************************************************************************************************
*/

void  OSView_RxIntEn (void)
{
#if OS_VIEW_COMM_SEL == OS_VIEW_COMM_0
    UCSR0B |= BIT7;
#endif

#if OS_VIEW_COMM_SEL == OS_VIEW_COMM_1
    UCSR1B |= BIT7;
#endif
}

/*
*********************************************************************************************************
*                                 Rx Communication handler for uC/OS-View
*
* Description: This function is called by OSView_RxISR (see OS_VIEWa.ASM) to process a received
*              character interrupt.
*********************************************************************************************************
*/

void  OSView_RxISRHandler (void)
{
#if OS_CRITICAL_METHOD == 3                          /* Allocate storage for CPU status register       */
    OS_CPU_SR  cpu_sr = 0;
#endif
    INT8U   rx_status;
	INT8U   rx_data;


#if OS_VIEW_COMM_SEL == OS_VIEW_COMM_0
    OS_ENTER_CRITICAL();
	rx_status = UCSR0A;
    rx_data   = UDR0;                                /* Clear interrupt source by reading Rx Data      */
    if (rx_status & BIT7) {                          /* Check if received character?                   */
        OSView_RxHandler(rx_data);			         /* Call the generic Rx handler                    */
    }
    OS_EXIT_CRITICAL();
#endif

#if OS_VIEW_COMM_SEL == OS_VIEW_COMM_1
    OS_ENTER_CRITICAL();
	rx_status = UCSR1A;
    rx_data   = UDR1;                                /* Clear interrupt source by reading Rx Data      */
    if (rx_status & BIT7) {                          /* Check if received character?                   */
        OSView_RxHandler(rx_data);			         /* Call the generic Rx handler                    */
    }
    OS_EXIT_CRITICAL();
#endif
}

/*
*********************************************************************************************************
*                                Rx/Tx Communication handler for uC/OS-View
*
* Description: This function is NOT called because the ATmega128 has a separate Rx and Tx ISR.
*********************************************************************************************************
*/

void  OSView_RxTxISRHandler (void)
{
}

/*$PAGE*/
/*
*********************************************************************************************************
*                                      Communication for uC/OS-View
*
* Description: Send 1 character to COM Port
*********************************************************************************************************
*/

void  OSView_Tx1 (INT8U c)
{
#if OS_VIEW_COMM_SEL == OS_VIEW_COMM_0
    UDR0 = c;
#endif

#if OS_VIEW_COMM_SEL == OS_VIEW_COMM_1
    UDR1 = c;
#endif
}

/*$PAGE*/
/*
*********************************************************************************************************
*                                       Disable Tx Interrupts
*********************************************************************************************************
*/

void  OSView_TxIntDis (void)
{
#if OS_VIEW_COMM_SEL == OS_VIEW_COMM_0
    UCSR0B &= ~BIT6;
#endif

#if OS_VIEW_COMM_SEL == OS_VIEW_COMM_1
    UCSR1B &= ~BIT6;
#endif
}

/*
*********************************************************************************************************
*                                       Enable Tx Interrupts
*********************************************************************************************************
*/

void  OSView_TxIntEn (void)
{
#if OS_VIEW_COMM_SEL == OS_VIEW_COMM_0
    UCSR0B |= BIT6;
#endif

#if OS_VIEW_COMM_SEL == OS_VIEW_COMM_1
    UCSR1B |= BIT6;
#endif
}

/*
*********************************************************************************************************
*                                 Tx Communication handler for uC/OS-View
*                                            (PORT SPECIFIC)
*
* Description: Handle transmission of a character
*
* Note(s)    : 1) This function is called by OSView_RxISR (see OS_VIEWa.ASM)
*********************************************************************************************************
*/

void  OSView_TxISRHandler (void)
{
    OSView_TxHandler();
}
#endif
